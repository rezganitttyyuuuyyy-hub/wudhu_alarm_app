import { createClient } from "npm:@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface PuzzleTemplate {
  key: string;
  category: string;
  difficulty: "easy" | "medium" | "hard";
  translations: Record<string, { question: string; options: [string, string, string, string]; correct: 0 | 1 | 2 | 3 }>;
}

// Multilingual Islamic trivia knowledge base
// Each puzzle has translations for all supported languages
// correct is the 0-indexed correct option
const PUZZLE_TEMPLATES: PuzzleTemplate[] = [
  {
    key: "prayers_per_day",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "كم عدد الصلوات المفروضة في اليوم والليلة؟", options: ["٣ صلوات", "٥ صلوات", "٧ صلوات", "١٠ صلوات"], correct: 1 },
      en: { question: "How many obligatory prayers are there in a day and night?", options: ["3 prayers", "5 prayers", "7 prayers", "10 prayers"], correct: 1 },
      fr: { question: "Combien de prières obligatoires y a-t-il par jour et nuit?", options: ["3 prières", "5 prières", "7 prières", "10 prières"], correct: 1 },
      tr: { question: "Günde ve gecede kaç farz namaz vardır?", options: ["3 namaz", "5 namaz", "7 namaz", "10 namaz"], correct: 1 },
      ur: { question: "ایک دن اور رات میں کتنی فرض نمازیں ہیں؟", options: ["٣ نمازیں", "٥ نمازیں", "٧ نمازیں", "١٠ نمازیں"], correct: 1 },
      id: { question: "Berapa banyak sholat wajib dalam sehari semalam?", options: ["3 sholat", "5 sholat", "7 sholat", "10 sholat"], correct: 1 },
      de: { question: "Wie viele Pflichtgebete gibt es pro Tag und Nacht?", options: ["3 Gebete", "5 Gebete", "7 Gebete", "10 Gebete"], correct: 1 },
      es: { question: "¿Cuántas oraciones obligatorias hay por día y noche?", options: ["3 oraciones", "5 oraciones", "7 oraciones", "10 oraciones"], correct: 1 },
    },
  },
  {
    key: "fajr_before_sunrise",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "أي صلاة تُؤدى قبل شروق الشمس؟", options: ["الفجر", "الظهر", "العصر", "العشاء"], correct: 0 },
      en: { question: "Which prayer is performed before sunrise?", options: ["Fajr", "Dhuhr", "Asr", "Isha"], correct: 0 },
      fr: { question: "Quelle prière est accomplie avant le lever du soleil?", options: ["Fajr", "Dhuhr", "Asr", "Isha"], correct: 0 },
      tr: { question: "Güneş doğmadan önce kılınan namaz hangisidir?", options: ["Sabah", "Öğle", "İkindi", "Yatsı"], correct: 0 },
      ur: { question: "سورج طلوع ہونے سے پہلے کون سی نماز ادا کی جاتی ہے؟", options: ["فجر", "ظہر", "عصر", "عشاء"], correct: 0 },
      id: { question: "Sholat mana yang dilakukan sebelum matahari terbit?", options: ["Subuh", "Zuhur", "Asar", "Isya"], correct: 0 },
      de: { question: "Welches Gebet wird vor Sonnenaufgang verrichtet?", options: ["Fadschr", "Zuhr", "Asr", "Ischa"], correct: 0 },
      es: { question: "¿Qué oración se realiza antes del amanecer?", options: ["Fajr", "Dhuhr", "Asr", "Isha"], correct: 0 },
    },
  },
  {
    key: "wudhu_before_prayer",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "ما هو العمل الذي يجب فعله قبل الصلاة؟", options: ["النوم", "الوضوء", "الأكل", "الجري"], correct: 1 },
      en: { question: "What must you do before praying?", options: ["Sleep", "Wudhu", "Eat", "Run"], correct: 1 },
      fr: { question: "Que devez-vous faire avant de prier?", options: ["Dormir", "Wudhu", "Manger", "Courir"], correct: 1 },
      tr: { question: "Namaz kılmadan önce ne yapmalısınız?", options: ["Uyumak", "Abdest", "Yemek", "Koşmak"], correct: 1 },
      ur: { question: "نماز سے پہلے کیا کرنا ضروری ہے؟", options: ["سونا", "وضو", "کھانا", "دوڑ"], correct: 1 },
      id: { question: "Apa yang harus Anda lakukan sebelum sholat?", options: ["Tidur", "Wudhu", "Makan", "Lari"], correct: 1 },
      de: { question: "Was müssen Sie vor dem Beten tun?", options: ["Schlafen", "Wudhu", "Essen", "Laufen"], correct: 1 },
      es: { question: "¿Qué debes hacer antes de orar?", options: ["Dormir", "Wudhu", "Comer", "Correr"], correct: 1 },
    },
  },
  {
    key: "isha_most_rakats",
    category: "islamic",
    difficulty: "medium",
    translations: {
      ar: { question: "أي صلاة لها أكثر عدد من الركعات؟", options: ["الفجر", "العصر", "المغرب", "العشاء"], correct: 3 },
      en: { question: "Which prayer has the most rakats?", options: ["Fajr", "Asr", "Maghrib", "Isha"], correct: 3 },
      fr: { question: "Quelle prière a le plus de rakats?", options: ["Fajr", "Asr", "Maghrib", "Isha"], correct: 3 },
      tr: { question: "Hangi namazın en çok rekatı vardır?", options: ["Sabah", "İkindi", "Akşam", "Yatsı"], correct: 3 },
      ur: { question: "کون سی نماز میں سب سے زیادہ رکعت ہیں؟", options: ["فجر", "عصر", "مغرب", "عشاء"], correct: 3 },
      id: { question: "Sholat mana yang memiliki rakaat terbanyak?", options: ["Subuh", "Asar", "Magrib", "Isya"], correct: 3 },
      de: { question: "Welches Gebet hat die meisten Rakats?", options: ["Fadschr", "Asr", "Maghrib", "Ischa"], correct: 3 },
      es: { question: "¿Qué oración tiene más rakats?", options: ["Fajr", "Asr", "Maghrib", "Isha"], correct: 3 },
    },
  },
  {
    key: "face_kaaba",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "في أي اتجاه يوجه المسلمون أثناء الصلاة؟", options: ["الكعبة", "المسجد", "الشمس", "القمر"], correct: 0 },
      en: { question: "In which direction do Muslims face during prayer?", options: ["The Kaaba", "The Mosque", "The Sun", "The Moon"], correct: 0 },
      fr: { question: "Dans quelle direction les musulmans se tournent-ils pendant la prière?", options: ["La Kaaba", "La Mosquée", "Le Soleil", "La Lune"], correct: 0 },
      tr: { question: "Namaz sırasında müslümanlar hangi yöne döner?", options: ["Kabe", "Cami", "Güneş", "Ay"], correct: 0 },
      ur: { question: "نماز کے دوران مسلمان کس طرف رخ کرتے ہیں؟", options: ["کعبہ", "مسجد", "سورج", "چاند"], correct: 0 },
      id: { question: "Ke arah mana umat Islam menghadap saat sholat?", options: ["Ka'bah", "Masjid", "Matahari", "Bulan"], correct: 0 },
      de: { question: "In welche Richtung blicken Muslime beim Gebet?", options: ["Die Kaaba", "Die Moschee", "Die Sonne", "Den Mond"], correct: 0 },
      es: { question: "¿En qué dirección se orientan los musulmanes durante la oración?", options: ["La Kaaba", "La Mezquita", "El Sol", "La Luna"], correct: 0 },
    },
  },
  {
    key: "pillars_of_islam",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "كم عدد أركان الإسلام؟", options: ["٣ أركان", "٤ أركان", "٥ أركان", "٦ أركان"], correct: 2 },
      en: { question: "How many pillars of Islam are there?", options: ["3 pillars", "4 pillars", "5 pillars", "6 pillars"], correct: 2 },
      fr: { question: "Combien de piliers l'Islam a-t-il?", options: ["3 piliers", "4 piliers", "5 piliers", "6 piliers"], correct: 2 },
      tr: { question: "İslam'ın kaç şartı vardır?", options: ["3 şart", "4 şart", "5 şart", "6 şart"], correct: 2 },
      ur: { question: "اسلام کے کتنے ارکان ہیں؟", options: ["٣ ارکان", "٤ ارکان", "٥ ارکان", "٦ ارکان"], correct: 2 },
      id: { question: "Berapa rukun Islam?", options: ["3 rukun", "4 rukun", "5 rukun", "6 rukun"], correct: 2 },
      de: { question: "Wie viele Säulen hat der Islam?", options: ["3 Säulen", "4 Säulen", "5 Säulen", "6 Säulen"], correct: 2 },
      es: { question: "¿Cuántos pilares tiene el Islam?", options: ["3 pilares", "4 pilares", "5 pilares", "6 pilares"], correct: 2 },
    },
  },
  {
    key: "ramadan_fasting",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "في أي شهر يصوم المسلمون؟", options: ["رجب", "رمضان", "شعبان", "محرم"], correct: 1 },
      en: { question: "In which month do Muslims fast?", options: ["Rajab", "Ramadan", "Shaban", "Muharram"], correct: 1 },
      fr: { question: "Quel mois les musulmans jeûnent-ils?", options: ["Rajab", "Ramadan", "Shaban", "Muharram"], correct: 1 },
      tr: { question: "Müslümanlar hangi ayda oruç tutar?", options: ["Recep", "Ramazan", "Şaban", "Muharrem"], correct: 1 },
      ur: { question: "مسلمان کس مہینے میں روزہ رکھتے ہیں؟", options: ["رجب", "رمضان", "شعبان", "محرم"], correct: 1 },
      id: { question: "Bulan apa umat Islam berpuasa?", options: ["Rajab", "Ramadan", "Sya'ban", "Muharram"], correct: 1 },
      de: { question: "In welchem Monat fasten Muslime?", options: ["Rajab", "Ramadan", "Scha'ban", "Muharram"], correct: 1 },
      es: { question: "¿En qué mes ayunan los musulmanes?", options: ["Rajab", "Ramadán", "Sha'ban", "Muharram"], correct: 1 },
    },
  },
  {
    key: "first_pillar",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "ما هو الركن الأول من أركان الإسلام؟", options: ["الصلاة", "الصوم", "الشهادة", "الزكاة"], correct: 2 },
      en: { question: "What is the first pillar of Islam?", options: ["Prayer", "Fasting", "Shahada", "Charity"], correct: 2 },
      fr: { question: "Quel est le premier pilier de l'Islam?", options: ["Prière", "Jeûne", "Shahada", "Charité"], correct: 2 },
      tr: { question: "İslam'ın ilk şartı nedir?", options: ["Namaz", "Oruç", "Şehadet", "Zekat"], correct: 2 },
      ur: { question: "اسلام کا پہلا رکن کیا ہے؟", options: ["نماز", "روزہ", "شہادت", "زکوٰة"], correct: 2 },
      id: { question: "Apa rukun Islam pertama?", options: ["Sholat", "Puasa", "Syahadat", "Zakat"], correct: 2 },
      de: { question: "Was ist die erste Säule des Islam?", options: ["Gebet", "Fasten", "Schahada", "Almosen"], correct: 2 },
      es: { question: "¿Cuál es el primer pilar del Islam?", options: ["Oración", "Ayuno", "Shahada", "Caridad"], correct: 2 },
    },
  },
  {
    key: "noon_prayer",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "أي صلاة تُؤدى عند الظهيرة؟", options: ["الفجر", "الظهر", "المغرب", "العشاء"], correct: 1 },
      en: { question: "Which prayer is performed at noon?", options: ["Fajr", "Dhuhr", "Maghrib", "Isha"], correct: 1 },
      fr: { question: "Quelle prière est accomplie à midi?", options: ["Fajr", "Dhuhr", "Maghrib", "Isha"], correct: 1 },
      tr: { question: "Öğle vaktinde kılınan namaz hangisidir?", options: ["Sabah", "Öğle", "Akşam", "Yatsı"], correct: 1 },
      ur: { question: "دوپہر میں کون سی نماز ادا کی جاتی ہے؟", options: ["فجر", "ظہر", "مغرب", "عشاء"], correct: 1 },
      id: { question: "Sholat mana yang dilakukan di siang hari?", options: ["Subuh", "Zuhur", "Magrib", "Isya"], correct: 1 },
      de: { question: "Welches Gebet wird um die Mittagszeit verrichtet?", options: ["Fadschr", "Zuhr", "Maghrib", "Ischa"], correct: 1 },
      es: { question: "¿Qué oración se realiza al mediodía?", options: ["Fajr", "Dhuhr", "Maghrib", "Isha"], correct: 1 },
    },
  },
  {
    key: "call_to_prayer",
    category: "islamic",
    difficulty: "medium",
    translations: {
      ar: { question: "ما هو مصطلح نداء الصلاة؟", options: ["الأذان", "الإقامة", "التكبير", "الدعاء"], correct: 0 },
      en: { question: "What is the term for the call to prayer?", options: ["Adhan", "Iqama", "Takbir", "Dua"], correct: 0 },
      fr: { question: "Quel est le terme pour l'appel à la prière?", options: ["Adhan", "Iqama", "Takbir", "Dua"], correct: 0 },
      tr: { question: "Ezana verilen terim nedir?", options: ["Ezan", "Kamet", "Tekbir", "Dua"], correct: 0 },
      ur: { question: "نماز کے لیے پکارنے کے عمل کو کیا کہتے ہیں؟", options: ["اذان", "اقامت", "تکبیر", "دعا"], correct: 0 },
      id: { question: "Apa istilah untuk panggilan sholat?", options: ["Adzan", "Iqamah", "Takbir", "Doa"], correct: 0 },
      de: { question: "Wie lautet der Begriff für den Gebetsruf?", options: ["Adhan", "Iqama", "Takbir", "Dua"], correct: 0 },
      es: { question: "¿Cuál es el término para el llamado a la oración?", options: ["Adhan", "Iqama", "Takbir", "Dua"], correct: 0 },
    },
  },
  {
    key: "fajr_rakats",
    category: "islamic",
    difficulty: "medium",
    translations: {
      ar: { question: "كم ركعة في صلاة الفجر؟", options: ["٢ ركعة", "٣ ركعات", "٤ ركعات", "٦ ركعات"], correct: 0 },
      en: { question: "How many rakats are in the Fajr prayer?", options: ["2 rakats", "3 rakats", "4 rakats", "6 rakats"], correct: 0 },
      fr: { question: "Combien de rakats dans la prière du Fajr?", options: ["2 rakats", "3 rakats", "4 rakats", "6 rakats"], correct: 0 },
      tr: { question: "Sabah namazında kaç rekat vardır?", options: ["2 rekat", "3 rekat", "4 rekat", "6 rekat"], correct: 0 },
      ur: { question: "فجر کی نماز میں کتنی رکعتیں ہیں؟", options: ["٢ رکعت", "٣ رکعت", "٤ رکعت", "٦ رکعت"], correct: 0 },
      id: { question: "Berapa rakaat dalam sholat Subuh?", options: ["2 rakaat", "3 rakaat", "4 rakaat", "6 rakaat"], correct: 0 },
      de: { question: "Wie viele Rakats hat das Fadschr-Gebet?", options: ["2 Rakats", "3 Rakats", "4 Rakats", "6 Rakats"], correct: 0 },
      es: { question: "¿Cuántos rakats tiene la oración del Fajr?", options: ["2 rakats", "3 rakats", "4 rakats", "6 rakats"], correct: 0 },
    },
  },
  {
    key: "touch_quran_wudhu",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "ماذا يجب أن تفعل قبل لمس القرآن؟", options: ["النوم", "الوضوء", "الأكل", "الجري"], correct: 1 },
      en: { question: "What must you do before touching the Quran?", options: ["Sleep", "Wudhu", "Eat", "Run"], correct: 1 },
      fr: { question: "Que devez-vous faire avant de toucher le Coran?", options: ["Dormir", "Wudhu", "Manger", "Courir"], correct: 1 },
      tr: { question: "Kur'an'a dokunmadan önce ne yapmalısınız?", options: ["Uyumak", "Abdest", "Yemek", "Koşmak"], correct: 1 },
      ur: { question: "قرآن کو چھونے سے پہلے کیا کرنا چاہیے؟", options: ["سونا", "وضو", "کھانا", "دوڑ"], correct: 1 },
      id: { question: "Apa yang harus Anda lakukan sebelum menyentuh Al-Quran?", options: ["Tidur", "Wudhu", "Makan", "Lari"], correct: 1 },
      de: { question: "Was müssen Sie tun, bevor Sie den Koran berühren?", options: ["Schlafen", "Wudhu", "Essen", "Laufen"], correct: 1 },
      es: { question: "¿Qué debes hacer antes de tocar el Corán?", options: ["Dormir", "Wudhu", "Comer", "Correr"], correct: 1 },
    },
  },
  {
    key: "qibla_direction",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "ما هو اتجاه القبلة؟", options: ["الشمال", "الجنوب", "نحو الكعبة", "الشرق"], correct: 2 },
      en: { question: "What is the direction of the Qibla?", options: ["North", "South", "Toward the Kaaba", "East"], correct: 2 },
      fr: { question: "Quelle est la direction de la Qibla?", options: ["Nord", "Sud", "Vers la Kaaba", "Est"], correct: 2 },
      tr: { question: "Kıble yönü nedir?", options: ["Kuzey", "Güney", "Kabe'ye doğru", "Doğu"], correct: 2 },
      ur: { question: "قبلہ کی سمت کیا ہے؟", options: ["شمال", "جنوب", "کعبہ کی طرف", "مشرق"], correct: 2 },
      id: { question: "Apa arah kiblat?", options: ["Utara", "Selatan", "Ke Ka'bah", "Timur"], correct: 2 },
      de: { question: "In welche Richtung zeigt die Qibla?", options: ["Norden", "Süden", "Zur Kaaba", "Osten"], correct: 2 },
      es: { question: "¿Cuál es la dirección de la Qibla?", options: ["Norte", "Sur", "Hacia la Kaaba", "Este"], correct: 2 },
    },
  },
  {
    key: "congregation_reward",
    category: "islamic",
    difficulty: "hard",
    translations: {
      ar: { question: "ما هو أجر الصلاة في جماعة مقارنة بالصلاة وحيداً؟", options: ["١٠ مرات", "٢٧ مرة", "٥٠ مرة", "١٠٠ مرة"], correct: 1 },
      en: { question: "What is the reward for praying in congregation compared to praying alone?", options: ["10 times", "27 times", "50 times", "100 times"], correct: 1 },
      fr: { question: "Quelle est la récompense de la prière en groupe par rapport à la prière seule?", options: ["10 fois", "27 fois", "50 fois", "100 fois"], correct: 1 },
      tr: { question: "Cemaatle namaz kılmanın sevabı tek başına kılmaya göre kaç katdır?", options: ["10 kat", "27 kat", "50 kat", "100 kat"], correct: 1 },
      ur: { question: "جماعت سے نماز پڑھنے کا اجر تنہا نماز کے مقابلے میں کتنا ہے؟", options: ["١٠ گنا", "٢٧ گنا", "٥٠ گنا", "١٠٠ گنا"], correct: 1 },
      id: { question: "Berapa pahala sholat berjamaah dibandingkan sholat sendiri?", options: ["10 kali", "27 kali", "50 kali", "100 kali"], correct: 1 },
      de: { question: "Wie hoch ist der Lohn für das Gebet in der Gemeinschaft im Vergleich zum alleinigen Gebet?", options: ["10-fach", "27-fach", "50-fach", "100-fach"], correct: 1 },
      es: { question: "¿Cuál es la recompensa por rezar en congregación comparado con rezar solo?", options: ["10 veces", "27 veces", "50 veces", "100 veces"], correct: 1 },
    },
  },
  {
    key: "zakat_percentage",
    category: "islamic",
    difficulty: "medium",
    translations: {
      ar: { question: "كم نسبة الزكاة الواجبة في المال؟", options: ["٢.٥٪", "٥٪", "١٠٪", "٢٠٪"], correct: 0 },
      en: { question: "What is the obligatory Zakat percentage on wealth?", options: ["2.5%", "5%", "10%", "20%"], correct: 0 },
      fr: { question: "Quel est le pourcentage obligatoire de la Zakat sur la richesse?", options: ["2.5%", "5%", "10%", "20%"], correct: 0 },
      tr: { question: "Zekatın mal üzerindeki farz oranı nedir?", options: ["%2.5", "%5", "%10", "%20"], correct: 0 },
      ur: { question: "مال پر زکوٰة کا کتنا فرض تناسب ہے؟", options: ["٢.٥٪", "٥٪", "١٠٪", "٢٠٪"], correct: 0 },
      id: { question: "Berapa persentase Zakat wajib pada harta?", options: ["2.5%", "5%", "10%", "20%"], correct: 0 },
      de: { question: "Wie hoch ist der Pflicht-Zakat-Prozentsatz auf Vermögen?", options: ["2,5%", "5%", "10%", "20%"], correct: 0 },
      es: { question: "¿Cuál es el porcentaje obligatorio del Zakat sobre la riqueza?", options: ["2.5%", "5%", "10%", "20%"], correct: 0 },
    },
  },
  {
    key: "hajj_location",
    category: "islamic",
    difficulty: "medium",
    translations: {
      ar: { question: "في أي مدينة يقع الكعبة المشرفة؟", options: ["المدينة", "مكة", "القدس", "استانبول"], correct: 1 },
      en: { question: "In which city is the Kaaba located?", options: ["Medina", "Mecca", "Jerusalem", "Istanbul"], correct: 1 },
      fr: { question: "Dans quelle ville se trouve la Kaaba?", options: ["Médine", "La Mecque", "Jérusalem", "Istanbul"], correct: 1 },
      tr: { question: "Kabe hangi şehirde bulunur?", options: ["Medine", "Mekke", "Kudüs", "İstanbul"], correct: 1 },
      ur: { question: "کعبہ کس شہر میں واقع ہے؟", options: ["مدینہ", "مکہ", "یروشلم", "استنبول"], correct: 1 },
      id: { question: "Di kota mana Ka'bah berada?", options: ["Madinah", "Mekkah", "Yerusalem", "Istanbul"], correct: 1 },
      de: { question: "In welcher Stadt befindet sich die Kaaba?", options: ["Medina", "Mekka", "Jerusalem", "Istanbul"], correct: 1 },
      es: { question: "¿En qué ciudad se encuentra la Kaaba?", options: ["Medina", "La Meca", "Jerusalén", "Estambul"], correct: 1 },
    },
  },
  {
    key: "prophet_muhammad",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "من هو آخر الأنبياء؟", options: ["موسى", "عيسى", "محمد", "إبراهيم"], correct: 2 },
      en: { question: "Who is the last prophet?", options: ["Musa", "Isa", "Muhammad", "Ibrahim"], correct: 2 },
      fr: { question: "Qui est le dernier prophète?", options: ["Musa", "Isa", "Muhammad", "Ibrahim"], correct: 2 },
      tr: { question: "Son peygamber kimdir?", options: ["Musa", "İsa", "Muhammed", "İbrahim"], correct: 2 },
      ur: { question: "آخری نبی کون ہے؟", options: ["موسٰی", "عیسٰی", "محمد", "ابراہیم"], correct: 2 },
      id: { question: "Siapa nabi terakhir?", options: ["Musa", "Isa", "Muhammad", "Ibrahim"], correct: 2 },
      de: { question: "Wer ist der letzte Prophet?", options: ["Musa", "Isa", "Muhammad", "Ibrahim"], correct: 2 },
      es: { question: "¿Quién es el último profeta?", options: ["Musa", "Isa", "Muhammad", "Ibrahim"], correct: 2 },
    },
  },
  {
    key: "holy_book",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "ما هو الكتاب المقدس عند المسلمين؟", options: ["التوراة", "الإنجيل", "القرآن", "الزبور"], correct: 2 },
      en: { question: "What is the holy book of Muslims?", options: ["Torah", "Gospel", "Quran", "Psalms"], correct: 2 },
      fr: { question: "Quel est le livre saint des musulmans?", options: ["Torah", "Évangile", "Coran", "Psaumes"], correct: 2 },
      tr: { question: "Müslümanların kutsal kitabı nedir?", options: ["Tevrat", "İncil", "Kur'an", "Zebur"], correct: 2 },
      ur: { question: "مسلمانوں کی مقدس کتاب کیا ہے؟", options: ["تورات", "انجیل", "قرآن", "زبور"], correct: 2 },
      id: { question: "Apa kitab suci umat Islam?", options: ["Taurat", "Injil", "Al-Quran", "Zabur"], correct: 2 },
      de: { question: "Was ist das heilige Buch der Muslime?", options: ["Thora", "Evangelium", "Koran", "Psalmen"], correct: 2 },
      es: { question: "¿Cuál es el libro sagrado de los musulmanes?", options: ["Torá", "Evangelio", "Corán", "Salmos"], correct: 2 },
    },
  },
  {
    key: "maghrib_after_sunset",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "أي صلاة تُؤدى بعد غروب الشمس؟", options: ["الفجر", "الظهر", "المغرب", "العشاء"], correct: 2 },
      en: { question: "Which prayer is performed after sunset?", options: ["Fajr", "Dhuhr", "Maghrib", "Isha"], correct: 2 },
      fr: { question: "Quelle prière est accomplie après le coucher du soleil?", options: ["Fajr", "Dhuhr", "Maghrib", "Isha"], correct: 2 },
      tr: { question: "Güneş battıktan sonra kılınan namaz hangisidir?", options: ["Sabah", "Öğle", "Akşam", "Yatsı"], correct: 2 },
      ur: { question: "سورج غروب کے بعد کون سی نماز ادا کی جاتی ہے؟", options: ["فجر", "ظہر", "مغرب", "عشاء"], correct: 2 },
      id: { question: "Sholat mana yang dilakukan setelah matahari terbenam?", options: ["Subuh", "Zuhur", "Magrib", "Isya"], correct: 2 },
      de: { question: "Welches Gebet wird nach Sonnenuntergang verrichtet?", options: ["Fadschr", "Zuhr", "Maghrib", "Ischa"], correct: 2 },
      es: { question: "¿Qué oración se realiza después del atardecer?", options: ["Fajr", "Dhuhr", "Maghrib", "Isha"], correct: 2 },
    },
  },
  {
    key: "asr_time",
    category: "islamic",
    difficulty: "medium",
    translations: {
      ar: { question: "متى تُؤدى صلاة العصر؟", options: ["قبل الشروق", "بعد الظهر", "بعد الغروب", "في منتصف الليل"], correct: 1 },
      en: { question: "When is the Asr prayer performed?", options: ["Before sunrise", "After noon", "After sunset", "At midnight"], correct: 1 },
      fr: { question: "Quand la prière du Asr est-elle accomplie?", options: ["Avant le lever du soleil", "Après midi", "Après le coucher du soleil", "À minuit"], correct: 1 },
      tr: { question: "İkindi namazı ne zaman kılınır?", options: ["Gün doğumundan önce", "Öğleden sonra", "Gün batımından sonra", "Gece yarısı"], correct: 1 },
      ur: { question: "عصر کی نماز کب ادا کی جاتی ہے؟", options: ["سورج طلوع سے پہلے", "دوپہر کے بعد", "غروب آفتاب کے بعد", "آدھی رات کو"], correct: 1 },
      id: { question: "Kapan sholat Asar dilakukan?", options: ["Sebelum matahari terbit", "Setelah siang", "Setelah matahari terbenam", "Tengah malam"], correct: 1 },
      de: { question: "Wann wird das Asr-Gebet verrichtet?", options: ["Vor Sonnenaufgang", "Nach dem Mittag", "Nach Sonnenuntergang", "Um Mitternacht"], correct: 1 },
      es: { question: "¿Cuándo se realiza la oración del Asr?", options: ["Antes del amanecer", "Después del mediodía", "Después del atardecer", "A medianoche"], correct: 1 },
    },
  },
  {
    key: "laylat_al_qadr",
    category: "islamic",
    difficulty: "hard",
    translations: {
      ar: { question: "ما هي أعظم ليلة في رمضان؟", options: ["ليلة القدر", "ليلة النصف", "ليلة الجمعة", "ليلة العيد"], correct: 0 },
      en: { question: "What is the greatest night in Ramadan?", options: ["Laylat al-Qadr", "Mid-Shaban night", "Friday night", "Eid night"], correct: 0 },
      fr: { question: "Quelle est la plus grande nuit du Ramadan?", options: ["Laylat al-Qadr", "Nuit du milieu de Shaban", "Nuit du vendredi", "Nuit de l'Aïd"], correct: 0 },
      tr: { question: "Ramazan'ın en büyük gecesi hangisidir?", options: ["Kadir Gecesi", "Şaban'ın ortası", "Cuma gecesi", "Bayram gecesi"], correct: 0 },
      ur: { question: "رمضان کی سب سے بڑی رات کون سی ہے؟", options: ["ليلة القدر", "شعبان کی نصف رات", "جمعہ کی رات", "عید کی رات"], correct: 0 },
      id: { question: "Apa malam terbesar di Ramadan?", options: ["Lailatul Qadr", "Pertengahan Sya'ban", "Malam Jumat", "Malam Idul Fitri"], correct: 0 },
      de: { question: "Was ist die größte Nacht im Ramadan?", options: ["Lailat al-Qadr", "Mitte-Scha'ban-Nacht", "Freitagnacht", "Eid-Nacht"], correct: 0 },
      es: { question: "¿Cuál es la noche más grande de Ramadán?", options: ["Laylat al-Qadr", "Noche de mediados de Sha'ban", "Noche del viernes", "Noche del Eid"], correct: 0 },
    },
  },
  {
    key: "five_pillars_names",
    category: "islamic",
    difficulty: "hard",
    translations: {
      ar: { question: "أي مما يلي ليس من أركان الإسلام الخمسة؟", options: ["الصلاة", "الزكاة", "الجهاد", "الحج"], correct: 2 },
      en: { question: "Which of the following is NOT one of the five pillars of Islam?", options: ["Prayer", "Zakat", "Jihad", "Hajj"], correct: 2 },
      fr: { question: "Lequel des suivants n'est PAS un des cinq piliers de l'Islam?", options: ["Prière", "Zakat", "Jihad", "Hajj"], correct: 2 },
      tr: { question: "Aşağıdakilerden hangisi İslam'ın beş şartından biri DEĞİLDİR?", options: ["Namaz", "Zekat", "Cihat", "Hac"], correct: 2 },
      ur: { question: "درج ذیل میں سے کون سا اسلام کے پانچ ارکان میں شامل نہیں؟", options: ["نماز", "زکوٰة", "جہاد", "حج"], correct: 2 },
      id: { question: "Mana yang BUKAN salah satu dari rukun Islam yang lima?", options: ["Sholat", "Zakat", "Jihad", "Haji"], correct: 2 },
      de: { question: "Welches ist KEINE der fünf Säulen des Islam?", options: ["Gebet", "Zakat", "Dschihad", "Haddsch"], correct: 2 },
      es: { question: "¿Cuál NO es uno de los cinco pilares del Islam?", options: ["Oración", "Zakat", "Yihad", "Hajj"], correct: 2 },
    },
  },
  {
    key: "wudhu_washing_parts",
    category: "islamic",
    difficulty: "medium",
    translations: {
      ar: { question: "كم مرة تغسل الأعضاء في الوضوء؟", options: ["مرة واحدة", "مرتين", "ثلاث مرات", "أربع مرات"], correct: 2 },
      en: { question: "How many times do you wash each body part in Wudhu?", options: ["Once", "Twice", "Three times", "Four times"], correct: 2 },
      fr: { question: "Combien de fois lavez-vous chaque partie du corps dans le Wudhu?", options: ["Une fois", "Deux fois", "Trois fois", "Quatre fois"], correct: 2 },
      tr: { question: "Abdestte her uzuv kaç kez yıkanır?", options: ["Bir kez", "İki kez", "Üç kez", "Dört kez"], correct: 2 },
      ur: { question: "وضو میں ہر عضو کتنی بار دھویا جاتا ہے؟", options: ["ایک بار", "دو بار", "تین بار", "چار بار"], correct: 2 },
      id: { question: "Berapa kali Anda membasuh setiap anggota badan dalam wudhu?", options: ["Sekali", "Dua kali", "Tiga kali", "Empat kali"], correct: 2 },
      de: { question: "Wie oft waschen Sie jeden Körperteil beim Wudhu?", options: ["Einmal", "Zweimal", "Dreimal", "Viermal"], correct: 2 },
      es: { question: "¿Cuántas veces lavas cada parte del cuerpo en el Wudhu?", options: ["Una vez", "Dos veces", "Tres veces", "Cuatro veces"], correct: 2 },
    },
  },
  {
    key: "eid_celebrations",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "كم عدد أعياد المسلمين في السنة؟", options: ["عيد واحد", "عيدان", "ثلاثة أعياد", "أربعة أعياد"], correct: 1 },
      en: { question: "How many Eid celebrations do Muslims have per year?", options: ["One Eid", "Two Eids", "Three Eids", "Four Eids"], correct: 1 },
      fr: { question: "Combien de fêtes de l'Aïd les musulmans ont-ils par an?", options: ["Un Aïd", "Deux Aïd", "Trois Aïd", "Quatre Aïd"], correct: 1 },
      tr: { question: "Müslümanların yılda kaç bayramı vardır?", options: ["Bir bayram", "İki bayram", "Üç bayram", "Dört bayram"], correct: 1 },
      ur: { question: "مسلمانوں کے سال میں کتنے عید ہوتے ہیں؟", options: ["ایک عید", "دو عید", "تین عید", "چار عید"], correct: 1 },
      id: { question: "Berapa banyak perayaan Idul Fitri yang dimiliki umat Islam per tahun?", options: ["Satu Idul Fitri", "Dua Idul Fitri", "Tiga Idul Fitri", "Empat Idul Fitri"], correct: 1 },
      de: { question: "Wie viele Eid-Feste haben Muslime pro Jahr?", options: ["Ein Eid", "Zwei Eid", "Drei Eid", "Vier Eid"], correct: 1 },
      es: { question: "¿Cuántas fiestas Eid tienen los musulmanes por año?", options: ["Un Eid", "Dos Eid", "Tres Eid", "Cuatro Eid"], correct: 1 },
    },
  },
  {
    key: "sujud_prostration",
    category: "islamic",
    difficulty: "medium",
    translations: {
      ar: { question: "ما هو السجود في الصلاة؟", options: ["الوقوف", "الركوع", "السجود على الأرض", "الجلوس"], correct: 2 },
      en: { question: "What is sujud in prayer?", options: ["Standing", "Bowing", "Prostration on the ground", "Sitting"], correct: 2 },
      fr: { question: "Qu'est-ce que le sujud dans la prière?", options: ["Debout", "Inclinaison", "Prosternation au sol", "Assis"], correct: 2 },
      tr: { question: "Namazda secde nedir?", options: ["Ayakta durmak", "Rükû", "Yere kapanmak", "Oturmak"], correct: 2 },
      ur: { question: "نماز میں سجدہ کیا ہے؟", options: ["کھڑا ہونا", "رکوع", "زمین پر سجدہ", "بیٹھنا"], correct: 2 },
      id: { question: "Apa itu sujud dalam sholat?", options: ["Berdiri", "Ruku", "Sujud ke tanah", "Duduk"], correct: 2 },
      de: { question: "Was ist der Sujud im Gebet?", options: ["Stehen", "Verbeugung", "Niederwerfung auf den Boden", "Sitzen"], correct: 2 },
      es: { question: "¿Qué es el sujud en la oración?", options: ["De pie", "Inclinación", "Postración en el suelo", "Sentado"], correct: 2 },
    },
  },
  {
    key: "tahajud_night_prayer",
    category: "islamic",
    difficulty: "hard",
    translations: {
      ar: { question: "ما هي صلاة التهجد؟", options: ["صلاة الظهر", "صلاة الليل", "صلاة العصر", "صلاة الجمعة"], correct: 1 },
      en: { question: "What is Tahajud prayer?", options: ["Noon prayer", "Night prayer", "Afternoon prayer", "Friday prayer"], correct: 1 },
      fr: { question: "Qu'est-ce que la prière du Tahajud?", options: ["Prière du midi", "Prière de nuit", "Prière de l'après-midi", "Prière du vendredi"], correct: 1 },
      tr: { question: "Tehacüt namazı nedir?", options: ["Öğle namazı", "Gece namazı", "İkindi namazı", "Cuma namazı"], correct: 1 },
      ur: { question: "تہجد کی نماز کیا ہے؟", options: ["ظہر کی نماز", "رات کی نماز", "عصر کی نماز", "جمعہ کی نماز"], correct: 1 },
      id: { question: "Apa itu sholat Tahajud?", options: ["Sholat Zuhur", "Sholat malam", "Sholat Asar", "Sholat Jumat"], correct: 1 },
      de: { question: "Was ist das Tahajud-Gebet?", options: ["Mittagsgebet", "Nachtgebet", "Nachmittagsgebet", "Freitagsgebet"], correct: 1 },
      es: { question: "¿Qué es la oración Tahajud?", options: ["Oración del mediodía", "Oración nocturna", "Oración de la tarde", "Oración del viernes"], correct: 1 },
    },
  },
  {
    key: "sadaqah_charity",
    category: "islamic",
    difficulty: "easy",
    translations: {
      ar: { question: "ما هو الصدقة في الإسلام؟", options: ["الصلاة", "الصدقة التطوعية", "الصوم", "الحج"], correct: 1 },
      en: { question: "What is Sadaqah in Islam?", options: ["Prayer", "Voluntary charity", "Fasting", "Pilgrimage"], correct: 1 },
      fr: { question: "Qu'est-ce que la Sadaqah en Islam?", options: ["Prière", "Charité volontaire", "Jeûne", "Pèlerinage"], correct: 1 },
      tr: { question: "İslam'da sadaka nedir?", options: ["Namaz", "Gönüllü sadaka", "Oruç", "Hac"], correct: 1 },
      ur: { question: "اسلام میں صدقہ کیا ہے؟", options: ["نماز", "رضاکارانہ خیرات", "روزہ", "حج"], correct: 1 },
      id: { question: "Apa itu Sadaqah dalam Islam?", options: ["Sholat", "Sedekah sukarela", "Puasa", "Haji"], correct: 1 },
      de: { question: "Was ist Sadaqah im Islam?", options: ["Gebet", "Freiwillige Spende", "Fasten", "Pilgerfahrt"], correct: 1 },
      es: { question: "¿Qué es Sadaqah en el Islam?", options: ["Oración", "Caridad voluntaria", "Ayuno", "Peregrinación"], correct: 1 },
    },
  },
];

function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const lang = url.searchParams.get("lang") || "en";
    const count = parseInt(url.searchParams.get("count") || "5", 10);
    const excludeParam = url.searchParams.get("exclude") || "";
    const excludeKeys = excludeParam ? excludeParam.split(",").filter(Boolean) : [];

    // Get auth token from header
    const authHeader = req.headers.get("Authorization");
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabase = createClient(
      supabaseUrl,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader || "" } } }
    );

    // Get user from session
    const { data: userData } = await supabase.auth.getUser();
    const userId = userData.user?.id;

    if (!userId) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get user's profile to find their ID
    const { data: profile } = await supabase
      .from("profiles")
      .select("id")
      .eq("user_id", userId)
      .maybeSingle();

    if (!profile) {
      return new Response(
        JSON.stringify({ error: "Profile not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get already-solved puzzle keys for this profile
    const { data: attempts } = await supabase
      .from("puzzle_attempts")
      .select("puzzle_key")
      .eq("profile_id", profile.id)
      .not("puzzle_key", "is", null);

    const solvedKeys = new Set<string>();
    if (attempts) {
      for (const a of attempts) {
        if (a.puzzle_key) solvedKeys.add(a.puzzle_key);
      }
    }

    // Also add the excluded keys from the request
    for (const k of excludeKeys) {
      solvedKeys.add(k);
    }

    // Filter out already-solved puzzles
    const available = PUZZLE_TEMPLATES.filter((t) => !solvedKeys.has(t.key));

    // If all puzzles have been solved, reset (allow all again - infinite mode)
    const pool = available.length > 0 ? available : PUZZLE_TEMPLATES;

    // Shuffle and pick count puzzles
    const shuffled = shuffleArray(pool);
    const selected = shuffled.slice(0, Math.min(count, shuffled.length));

    // Build response with language-specific translations
    const puzzles = selected.map((template) => {
      const translation = template.translations[lang] || template.translations["en"];
      return {
        key: template.key,
        question: translation.question,
        option_a: translation.options[0],
        option_b: translation.options[1],
        option_c: translation.options[2],
        option_d: translation.options[3],
        correct_answer: ["a", "b", "c", "d"][translation.correct] as "a" | "b" | "c" | "d",
        difficulty: template.difficulty,
        category: template.category,
      };
    });

    return new Response(
      JSON.stringify({ puzzles, language: lang }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
